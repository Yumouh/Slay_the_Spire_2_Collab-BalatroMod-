SMODS.Joker{ --汇流
    key = "convergence",
    config = {
        extra = {
            gold_odds = 35   -- 黄金牌出现的百分比概率
        }
    },
    loc_txt = {},
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["slaythes_slaythes_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.gold_odds}}
    end,

    calculate = function(self, card, context)
        -- 只在弃牌事件触发，且不是针对单张卡牌的循环
        if context.pre_discard and not context.individual then
            -- 收集所有未被选中弃掉的牌（留在手中的牌）
            local stay_cards = {}
            for _, c in ipairs(G.hand.cards) do
                if not c.highlighted then
                    table.insert(stay_cards, c)
                end
            end

            -- 有留牌时才触发
            if #stay_cards > 0 then
                -- 从留牌中伪随机选取一张
                local chosen = pseudorandom_element(stay_cards, pseudoseed('convergence'))
                if chosen then
                    -- 按概率赋予黄金或钢铁增强
                    if SMODS.pseudorandom_probability(card, 'gold_enhance', card.ability.extra.gold_odds, 100, 'j_slaythes_convergence', false) then
                        chosen:set_ability(G.P_CENTERS.m_gold, nil, true)
                        card_eval_status_text(card, 'extra', nil, nil, nil, {
                            message = "黄金",
                            colour = G.C.GOLD
                        })
                    else
                        chosen:set_ability(G.P_CENTERS.m_steel, nil, true)
                        card_eval_status_text(card, 'extra', nil, nil, nil, {
                            message = "钢铁",
                            colour = G.C.BLUE
                        })
                    end
                end
            end
        end
    end
}