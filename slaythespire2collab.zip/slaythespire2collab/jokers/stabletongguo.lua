SMODS.Joker{ --坚定不移
    key = "stabletongguo",
    config = {
        extra = {
            mult0 = 5
        }
    },
    loc_txt = {},
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["stsco_slaythes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if context.other_card == context.scoring_hand[#context.scoring_hand] then
                return {
                    mult = context.other_card:get_chip_bonus() * 2
                }
            end
        end
    end
}