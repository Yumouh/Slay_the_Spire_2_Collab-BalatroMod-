SMODS.Joker{ --回响形态
    key = "form_orm_rm_m",
    config = {
        extra = {
            count = 3,
            act = 1,
            pb_bonus_68a5b14e = 1
        }
    },
    loc_txt = {},
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["stsco_stsco_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.count}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if to_big(card.ability.extra.act) == to_big(1) and to_big(card.ability.extra.count) > to_big(0) then
                -- 给予永久重新触发
                context.other_card.ability.perma_retriggers = (context.other_card.ability.perma_retriggers or 0) + 1
                card.ability.extra.act = 0
                card.ability.extra.count = card.ability.extra.count - 1

                -- 次数耗尽后自毁
                if to_big(card.ability.extra.count) <= to_big(0) then
                    local target_joker = card
                    if target_joker then
                        target_joker.getting_sliced = true
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                return true
                            end
                        }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                    end
                end

                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT },
                    card = card
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            return {
                func = function()
                    card.ability.extra.act = 1
                    return true
                end,
                message = "激活！"
            }
        end
    end
}