return {
    descriptions = {
        Joker={
            j_stsco_convergence={
                name = '汇流',
                text = {
                    '每当你{C:red}弃牌{}，留在手',
                    '中的随机一张牌变为',
                    '{C:attention}黄金牌{}或{C:attention}钢铁牌{}'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_rucishenhao={
                name = '如此甚好',
                text = {
                    '每有{C:attention}3{}张牌计分，',
                    '下次计分时',
                    '给予{C:red}+#1#{}倍率并',
                    '使这一数值{C:red}+1{}'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_destroy_destroy={
                name = '抉择，抉择',
                text = {
                    '每当你使用{C:planet}星球牌{}',
                    '或{C:tarot}塔罗牌{},在消耗栏',
                    '中生成两张复制',
                    '（每底注限一次）'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_crimsonthorne={
                name = '绯红披风',
                text = {
                    '回合结束时给予{C:money}8${}',
                    '盲注分数要求{C:red}+25%{}'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_BlackYongbao={
                name = '黑暗之拥',
                text = {
                    '每出售一张牌，',
                    '手牌上限{C:attention}+1{}',
                    '回合结束时{C:red}重置{}',
                    '{C:inactive}（当前+#1#）{}'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_stabletongguo={
                name = '坚定不移',
                text = {
                    '{C:attention}最后一张{}记分牌给予',
                    '自身{C:blue}筹码值{}两倍的{C:red}倍率{}'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_2000VOLT={
                name = '电流相生',
                text = {
                    '{C:red}+#1#{}倍率',
                    '{C:attention}Boss盲注{}被',
                    '击败时翻倍'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_form_orm_rm_m={
                name = '回响形态',
                text = {
                    '每底注{C:attention}第一张{}记分牌',
                    '永久获得一次{C:attention}重新触发{}',
                    '（{C:attention}#1#{}次后{C:red}自毁{}）'
                },
                unlock = {
                    '默认解锁。',
                },
            },
            j_stsco_one_punch={
                name = '万物一心',
                text = {
                    '{C:attention}增强牌{}都被',
                    '洗到{C:red}牌堆底{}'
                },
                unlock = {
                    '默认解锁。',
                },
            },
        },
    },
}
