SMODS.Joker{ --万物一心
    key = "one_punch",
    config = {
        extra = {
        }
    },
    loc_txt = {},
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["stsco_stsco_jokers"] = true },

    -- 添加能力：将增强牌洗到牌堆底
    calculate = function(self, card, context)
        -- 此函数无需额外动作，能力通过全局重写 shuffle 实现
        -- 保留 calculate 以满足小丑基础结构
    end
}

-- 保存原始的 shuffle 函数
local original_shuffle = CardArea.shuffle

-- 重写 shuffle，实现“增强牌洗入牌堆底”
function CardArea:shuffle(_seed)
    -- 先执行原始洗牌逻辑
    local result = original_shuffle(self, _seed)
    
    -- 检测玩家是否拥有“万物一心”小丑
    local has_one_punch = next(SMODS.find_card("j_stsco_one_punch"))
    -- 如果拥有该小丑，将增强牌移到牌堆底部
    if has_one_punch then
        local enhanced_cards = {}
        -- 从后向前遍历，避免索引错乱
        for i = #self.cards, 1, -1 do
            local c = self.cards[i]
            -- 判断是否为增强牌：ability.set == 'Enhanced'
            if c.ability and c.ability.set == 'Enhanced' then
                table.insert(enhanced_cards, c)
                table.remove(self.cards, i)
            end
        end
        -- 将收集到的增强牌按原顺序追加到牌堆末尾（底部）
        for _, c in ipairs(enhanced_cards) do
            table.insert(self.cards, 1, c)
        end
    end
    
    return result
end