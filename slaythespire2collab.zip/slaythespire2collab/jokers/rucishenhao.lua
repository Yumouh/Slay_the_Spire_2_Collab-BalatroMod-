
SMODS.Joker{ --如此甚好
    key = "rucishenhao",
    config = {
        extra = {
            great = 0,
            count = 0
        }
    },
    loc_txt = {},
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["slaythes_slaythes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.great, card.ability.extra.count}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if to_big((card.ability.extra.count or 0)) == to_big(3) then
                card.ability.extra.count = 0
                card.ability.extra.great = (card.ability.extra.great) + 1
                return {
                    message = "升级！",
                    extra = {
                        mult = card.ability.extra.great
                    }
                }
            else
                card.ability.extra.count = (card.ability.extra.count) + 1
            end
        end
    end
}