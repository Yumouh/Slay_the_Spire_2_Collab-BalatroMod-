
SMODS.Joker{ --黑暗之拥
    key = "BlackYongbao",
    config = {
        extra = {
            shangxian = 0,
            ok = 1
        }
    },
    loc_txt = {},
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["stsco_slaythes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.shangxian}}
    end,
    
    calculate = function(self, card, context)
        if context.selling_card  then
            return {
                func = function()
                    card.ability.extra.shangxian = (card.ability.extra.shangxian) + 1
                    G.hand:change_size(card.ability.extra.ok)
                    return true
                end,
                message = "升级！"
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    G.hand:change_size(-card.ability.extra.shangxian)
                    card.ability.extra.shangxian = 0
                    return true
                end,
                message = "重置！"
            }
        end
    end,
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-card.ability.extra.shangxian)
    end
}