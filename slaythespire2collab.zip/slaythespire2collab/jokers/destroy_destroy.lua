SMODS.Joker{ --抉择，抉择
    key = "destroy_destroy",
    config = {
        extra = {
            act = 1
        }
    },
    loc_txt = {},
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["stsco_slaythes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.act}}
    end,
    
    calculate = function(self, card, context)
        if context.using_consumeable then
            if to_big((card.ability.extra.act or 0)) == to_big(1) then
                local used = context.consumeable  -- 获取正在使用的消耗牌
                if used and used.ability.set == 'Tarot' or used.ability.set == 'Planet'then
                    return {
                        func = function()
                            local slots = math.min(2, G.consumeables.config.card_limit - #G.consumeables.cards)
                            for i = 1, slots do
                                G.E_MANAGER:add_event(Event({
                                    trigger = 'after',
                                    delay = 0.4,
                                    func = function()
                                        play_sound('timpani')
                                        -- 复制当前使用的消耗牌
                                        local new_card = copy_card(used, nil, nil, nil, nil, true)
                                        new_card:add_to_deck()
                                        G.consumeables:emplace(new_card)
                                        card:juice_up(0.3, 0.5)
                                        return true
                                    end
                                }))
                            end
                            delay(0.6)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = '复制', colour = G.C.PURPLE})
                            return true
                        end,
                        extra = {
                            func = function()
                                card.ability.extra.act = 0  -- 消耗本次使用机会
                                return true
                            end,
                            colour = G.C.BLUE
                        }
                    }
                end
            end
        end
        -- 底注结束（击败 Boss 后）重置使用次数
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if to_big((card.ability.extra.act or 0)) == to_big(0) then
                return {
                    func = function()
                        card.ability.extra.act = 1
                        return true
                    end,
                    message = "激活！"
                }
            end
        end
    end
}