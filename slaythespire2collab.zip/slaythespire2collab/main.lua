SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/convergence.lua"))()
    assert(SMODS.load_file("jokers/rucishenhao.lua"))()
    assert(SMODS.load_file("jokers/destroy_destroy.lua"))()
    assert(SMODS.load_file("jokers/crimsonthorne.lua"))()
    assert(SMODS.load_file("jokers/BlackYongbao.lua"))()
    assert(SMODS.load_file("jokers/stabletongguo.lua"))()
    assert(SMODS.load_file("jokers/2000VOLT.lua"))()
    assert(SMODS.load_file("jokers/form_orm_rm_m.lua"))()
    assert(SMODS.load_file("jokers/one_punch.lua"))()
end
SMODS.ObjectType({
    key = "stsco_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "stsco_slaythes_jokers",
    cards = {
        ["j_stsco_convergence"] = true,
        ["j_stsco_rucishenhao"] = true,
        ["j_stsco_destroy_destroy"] = true,
        ["j_stsco_crimsonthorne"] = true,
        ["j_stsco_BlackYongbao"] = true,
        ["j_stsco_stabletongguo"] = true
    },
})

SMODS.ObjectType({
    key = "stsco_stsco_jokers",
    cards = {
        ["j_stsco_2000VOLT"] = true,
        ["j_stsco_form_orm_rm_m"] = true,
        ["j_stsco_one_punch"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end